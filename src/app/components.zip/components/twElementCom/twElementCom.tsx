"use client";
// Initialization for ES Users
import { Input, Timepicker, initTE, Datepicker } from "tw-elements";
import { useEffect } from "react";
const TwElementCom = () => {
  useEffect(() => {
    initTE({ Input, Timepicker, Datepicker });
  }, []);
  return null;
};

export default TwElementCom;
